<?php

namespace ManiaLivePlugins\eXpansion\TM_Scoretable;

class Config extends \ManiaLib\Utils\Singleton
{

	public $tm_score_columns = 2;
	public $tm_score_lines = 8;
}

?>