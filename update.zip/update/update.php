<?php

include("classes/Webaccess.php");
include("classes/GbxRemote.inc.php");

class autoUpdater {

    /** @var IXR_Client_Gbx */
    private $client;

    /** @var \Webaccess */
    private $access;
    private $recieveLoopActive = true;
// these are used for async webaccess 
    private $read;
    private $write;
    private $except;
    private $count = 0;
    private $lastPercentage = 0;
    private $updateInfo = null;
    private $currentVersion;
    private $stamp = 0;

    public function __construct($argv) {
	if (!isset($argv[1]) && !isset($argv[2]) && !isset($argv[3]) && !isset($argv[4]) && !isset($argv[5])) {
	    echo "wrong argument count!!!";
	    $this->end("auto update can't start.");
	}
	$this->currentVersion = $argv[1];
	$server = $argv[2];
	$port = $argv[3];
	$user = $argv[4];
	$pass = $argv[5];

	global $_recieveCallback;
	$this->client = new IXR_Client_Gbx();
	if (!$this->client->InitWithIp($server, $port)) {
	    $this->end("Can't connect to maniaplanet");
	}

	if (!$this->client->query("Authenticate", $user, $pass)) {
	    $this->end("Can't authenticate");
	}

	$this->read = array();
	$this->write = array();
	$this->except = array();
	$this->access = new \Webaccess();
	$_recieveCallback = array($this, "progress");
	$json = file_get_contents("http://reaby.kapsi.fi/ml/update/index.php");
	$data = json_decode($json);
	if ($data === NULL) {
	    $this->end("updater service is down, or returned bad data.");
	}
	$this->updateInfo = $data;
	
	if (version_compare($this->updateInfo->version, $this->currentVersion, "lt")) {
	    $this->end("no new version available");
	}
	if ($this->updateInfo->version == $this->currentVersion) {
	    $this->end("no new version available, you are already on latest version");
	}
	$this->sendChat("Starting update process...");
	$this->access->request("http://reaby.kapsi.fi/ml/update/" . $this->updateInfo->fileName, array(array($this, "ready")), null);
	$this->recieveLoop();
    }

    public function progress($recvsize, $spool) {

	$recv = round($recvsize / 1024);
	$percentageNow = ( $recvsize / $this->updateInfo->fileSize ) * 100;

	if ($this->lastPercentage != round($percentageNow)) {
	    $this->lastPercentage = round($percentageNow);
	    $this->triggerGameUpdate($percentageNow);
	}
    }

    public function triggerGameUpdate($percentage, $force = false) {

	if ($this->stamp != time() || $force) {
	    $this->stamp = time();
	    $xml = '<manialink version="1" id="expUpdate"> 
		<quad posn="1000 0" sizen="10 10" halign="center" bgcolor="0005" />
	
		<script><!--
		main() {
		declare persistent Real updateValue;		
		 updateValue = ' . $this->getNumber(round($percentage / 100, 6)) . ';		
		}
		
		--></script>
			
		</manialink>';

	    $this->client->query("SendDisplayManialinkPage", $xml, 0, false);
	}
    }

    private function getNumber($number) {
	return number_format((float) $number, 2, '.', '');
    }

    private function sendChat($string) {
	$this->client->query("ChatSendServerMessage", $string);
    }

    public function ready($request) {
	$this->recieveLoopActive = false;
	$this->triggerGameUpdate(100, true);

	file_put_contents($this->updateInfo->fileName, $request['Message']);
	unset($request); // free memory
	$this->sendChat("Unzipping...");
	try {
	    $zip = new \ZipArchive();
	    $zip->open($this->updateInfo->fileName);
	    $zip->extractTo(dirname(__DIR__));
	    $zip->close();
	} catch (\Exception $e) {
	    exit("an error occurred while extracting the update" . $e->getMessage());
	}

	// unlink($this->updateInfo->fileName);				
	$this->end("Update Done, please restart controller.");
    }

    private function end($string) {
	$this->client->query("ChatSendServerMessage", $string);
	$this->client->Terminate();
	exit($string);
    }

    private function recieveLoop() {
	$i = 0;
	while ($this->recieveLoopActive) {
	    $i++;	    
	    try {
		$this->access->select($this->read, $this->write, $this->except, 0);
		if ($i > 10000) {
		    $this->recieveLoopActive = false;
		    $this->end("Timeout has occurred while contacting server, please try later to update!");
		}
	    } catch (\Exception $e) {
		$this->recieveLoopActive = false;
		echo $e->getMessage();
		$this->end("error:" . $e->getMessage());
	    }
	}
    }

}

new \autoUpdater($argv);


